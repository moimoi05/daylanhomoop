package org.example.daylanhomoop_daylaela;

import java.io.IOException;

public class main {

    public static void main(String[] args) throws IOException, IOException {
        DictionaryManagement dictionaryManagement = new DictionaryManagement();
        dictionaryManagement.insertFromFile();
        dictionaryManagement.dictionaryLookup();
        dictionaryManagement.fixWord();
        dictionaryManagement.dictionaryLookup();
        dictionaryManagement.dictionaryLookup();
        dictionaryManagement.removeWord();
        dictionaryManagement.dictionaryLookup();
        dictionaryManagement.dictionaryLookup();

        /*
        Enter the English word to look up: goodbye
        Tam biet
        Enter the English word to edit: goodbye
        Enter the new Vietnamese meaning: Cut
        Word updated successfully.
        Enter the English word to look up: hello
        Xin chao
        Enter the English word to look up: goodbye
        Cut
        Enter the English word to delete: HeLLo
        Word removed successfully.
        Enter the English word to look up: hello
        Word not found in the dictionary.
        Enter the English word to look up: GooDByE
        Cut
         */

        dictionaryManagement.addWordToDictionary("train", new Word("train", "Tau"));
        dictionaryManagement.dictionaryExportToFile();
    }
}
