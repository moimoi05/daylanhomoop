module org.example.daylanhomoop_daylaela {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires com.almasb.fxgl.all;

    opens org.example.daylanhomoop_daylaela to javafx.fxml;
    exports org.example.daylanhomoop_daylaela;
}